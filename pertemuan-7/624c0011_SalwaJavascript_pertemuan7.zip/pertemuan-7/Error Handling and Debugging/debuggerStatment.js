function myFunction() {
    let x = 10;
    debugger;
    console.log('value of x:'. x);
}

myFunction();