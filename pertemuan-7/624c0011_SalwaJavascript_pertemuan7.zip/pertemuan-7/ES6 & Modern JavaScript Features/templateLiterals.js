// introduction to template literals

const name = 'John';
const greeting = 'Hello, ${name}!';

// Multiline Strings
const multilineString = `
This is a multiline
string using template literals.
`;